/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package praktikum11.tugas;


/**
 *
 * @author zulfa
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Pengarang pengarang1 = new Pengarang("Tere LIye");
        Pengarang pengarang2 = new Pengarang("Dewi Lestari");
        
        Buku buku1 = new Buku("Bumi", pengarang1);
        Buku buku2 = new Buku("Rash", pengarang2);
        
        Perpustakaan perpustakaan = new Perpustakaan(5);
        perpustakaan.tambahBuku(buku1);
        perpustakaan.tambahBuku(buku2);
        
        perpustakaan.tampilkanBuku();
    }
    
}
