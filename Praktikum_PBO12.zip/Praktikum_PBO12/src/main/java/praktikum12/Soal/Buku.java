/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum12.Soal;


import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author zulfa
 */
class Buku implements Serializable {
    private String judul;
    private String pengarang;
    private int tahun_terbit;
    
    public Buku(String judul, String pengarang, int tahun_terbit) {
        this.judul = judul;
        this.pengarang = pengarang;
        this.tahun_terbit = tahun_terbit;
    }
    
    @Override
    public String toString() {
        return "Judul: " + judul + ", Pengarang: " + pengarang + ", Tahun: " + tahun_terbit;
    }

    
    public void tampilkanInfo() {
        System.out.println("Judul buku   : " + judul);
        System.out.println("Pengarang    : " + pengarang);
        System.out.println("Tahun terbit : " + tahun_terbit); 
    }
}
