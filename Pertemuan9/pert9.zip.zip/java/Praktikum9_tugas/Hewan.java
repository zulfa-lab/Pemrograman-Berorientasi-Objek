/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Praktikum9_tugas;

/**
 *
 * @author zulfa
 */
// Definisi kelas abstrak
abstract class Hewan {
    // Metode abstrak
    abstract void suara();
    // Metode dengan implementasi
    void info() {
        System.out.println("Hewan mengeluarkan suara.");
    }
    
}

// Kelas turunan dari Hewan
class Kucing extends Hewan {
    @Override
    void suara() {
        System.out.println("Kucing mengeluarkan suara: Meong");
    }
}

class Anjing extends Hewan {
    @Override
    void suara(){
        System.out.println("Anjing mengeluarkan suara: Guk Guk");
    }
}
