/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Praktikum9_tugas;

/**
 *
 * @author zulfa
 */
// Kode utama untuk pengujian
public class Main {
    public static void main(String[] args) {
        Hewan kucing = new Kucing();
        Hewan anjing = new Anjing();
        
        anjing.suara();
        anjing.info();
        
        kucing.suara();
        kucing.info();
    
    }
    
}
