/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package praktikum10.tugas;

public class Main {

    public static void main(String[] args) {
        System.out.println("*** Detail pembayaran ***");
        System.out.println();
        
        System.out.println("Elektronik");
        // Objek elektronik
        double hargaelektronik = 1500000;
        Pembayaran elektronik = new Elektronik();
        double pajakelektronik = elektronik.hitungPajak(hargaelektronik);
        System.out.println("Harga elektronik                     : Rp" + hargaelektronik);
        System.out.println("Hitung pajak elektronik (10%)        : Rp" + pajakelektronik); 
        System.out.println("Harga elektronik setelah pajak       : Rp" + (hargaelektronik + pajakelektronik));
        
        System.out.println();
        // Objek makanan
        System.out.println("Makanan");
        double hargamakanan = 100000;
        Pembayaran makanan = new Makanan();
        double pajakmakanan = makanan.hitungPajak(hargamakanan);
        System.out.println("Harga makanan                        : Rp" + hargamakanan);
        System.out.println("Hitung pajak makanan (5%)            : Rp" + pajakmakanan);
        System.out.println("Harga makanan setelah ditambah pajak : Rp" + (hargamakanan + pajakmakanan));
    }
}
