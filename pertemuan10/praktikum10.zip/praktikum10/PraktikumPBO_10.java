/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package praktikum10;

/**
 *
 * @author zulfa
 */
public class PraktikumPBO_10 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
