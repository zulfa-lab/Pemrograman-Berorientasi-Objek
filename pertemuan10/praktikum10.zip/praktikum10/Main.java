/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package praktikum10;

public class Main {

    public static void main(String[] args) {
        // Objek penjumlahan
        OperasiHitung penjumlahan = new Penjumlahan();
        System.out.println("Penjumlahan: " + 
                penjumlahan.hitung(10, 5)); //output: 15
        
        // Objek pengurangan
        OperasiHitung pengurangan = new Pengurangan();
        System.out.println("Pengurangan:  " +
                pengurangan.hitung(10, 5)); // Outpur: 5
      
    }
    
}
